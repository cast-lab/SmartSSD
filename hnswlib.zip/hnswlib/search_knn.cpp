#include <queue>

typedef float dist_t;
typedef size_t labeltype;
typedef unsigned int tableint;
typedef unsigned int linklistsizeint;

// Parameters
static const size_t ef_ = 200;
static const int maxlevel_ = 10;
static size_t max_elements_ = 100000;

// Memory
static char data_level0_memory_;


char *getDataByInternalId(tableint internal_id) const {
	return (data_level0_memory_ + internal_id * size_data_per_element_ + offsetData_);
};

//
// Standalone version of searchKnn in hnswalg.h
//
std::priority_queue<std::pair<dist_t, labeltype >> search_knn(
	const void *query_data,
	size_t k,
	tableint enterpoint_node_,
	) const {
	tableint currObj = enterpoint_node_;
	dist_t curdist = fstdistfunc_(query_data, getDataByInternalId(enterpoint_node_), dist_func_param_);

	for (int level = maxlevel_; level > 0; level--) {
		bool changed = true;
		while (changed) {
			changed = false;
			unsigned int *data;

			data = (unsigned int *)get_linklist(currObj, level);
			int size = getListCount(data);
			tableint *datal = (tableint *)(data + 1);
			for (int i = 0; i < size; i++) {
				tableint cand = datal[i];
				if (cand < 0 || cand > max_elements_)
					throw std::runtime_error("cand error");
				dist_t d = fstdistfunc_(query_data, getDataByInternalId(cand), dist_func_param_);

				if (d < curdist) {
					curdist = d;
					currObj = cand;
					changed = true;
				}
			}
		}
	}

	std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates;
	if (has_deletions_) {
		std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates1 = searchBaseLayerST<true>(
			currObj, query_data, std::max(ef_, k));
		top_candidates.swap(top_candidates1);
	}
	else {
		std::priority_queue<std::pair<dist_t, tableint>, std::vector<std::pair<dist_t, tableint>>, CompareByFirst> top_candidates1 = searchBaseLayerST<false>(
			currObj, query_data, std::max(ef_, k));
		top_candidates.swap(top_candidates1);
	}
	std::priority_queue<std::pair<dist_t, labeltype >> results;
	while (top_candidates.size() > k) {
		top_candidates.pop();
	}
	while (top_candidates.size() > 0) {
		std::pair<dist_t, tableint> rez = top_candidates.top();
		results.push(std::pair<dist_t, labeltype>(rez.first, getExternalLabel(rez.second)));
		top_candidates.pop();
	}
	return results;
};