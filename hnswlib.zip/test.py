import hnswlib
import numpy as np
import time

#for i in range(1,10):	
#	print("Repeat: %d"%i)
#	time.sleep(2)

	dim = 128
	num_elements = 10000

	# Generating sample data
	data = np.float32(np.random.random((num_elements, dim)))
	data_labels = np.arange(num_elements)

	# Declaring index
	p = hnswlib.Index(space = 'l2', dim = dim) # possible options are l2, cosine or ip

	# Initing index - the maximum number of elements should be known beforehand
	p.init_index(max_elements = num_elements, ef_construction = 200, M = 16)

	# Element insertion (can be called several times):
	p.add_items(data, data_labels)

	# Controlling the recall by setting ef:
	p.set_ef(50) # ef should always be > k

	# Query dataset, k - number of closest elements (returns 2 numpy arrays)
	labels, distances = p.knn_query(data, k = 1)
